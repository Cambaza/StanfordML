function [C, sigma] = dataset3Params(X, y, Xval, yval)
%EX6PARAMS returns your choice of C and sigma for Part 3 of the exercise
%where you select the optimal (C, sigma) learning parameters to use for SVM
%with RBF kernel
%   [C, sigma] = EX6PARAMS(X, y, Xval, yval) returns your choice of C and 
%   sigma. You should complete this function to return the optimal C and 
%   sigma based on a cross-validation set.
%

% You need to return the following variables correctly.
C = 1;
sigma = 0.3;

% ====================== YOUR CODE HERE ======================
% Instructions: Fill in this function to return the optimal C and sigma
%               learning parameters found using the cross validation set.
%               You can use svmPredict to predict the labels on the cross
%               validation set. For example, 
%                   predictions = svmPredict(model, Xval);
%               will return the predictions on the cross validation set.
%
%  Note: You can compute the prediction error using 
%        mean(double(predictions ~= yval))
%
vary=[0.01,0.03,0.1,0.3,1,3,10,30];
J=zeros(length(vary),length(vary));
k=500;
for i=1:length(vary)
    C=vary(1,i);
        for j=1:length(vary)
            sigma=vary(1,j);
            model= svmTrain(X, y, C, @(x1, x2) gaussianKernel(x1, x2, sigma)); 
            pred=svmPredict(model,Xval);
            J(i,j)=mean(double(pred~=yval));
            if J(i,j)<k
                k=J(i,j);
                Csup=vary(1,i);
                sigmasup=vary(1,j);
            end;
        end;
    
end;
C=Csup;
sigma=sigmasup;
%x=0;
%i=0;
%j=0;
%x=min(min(J));
%for h=1:length(vary)
%    for t=1:length(vary)
%        if J(h,t)==n
%            i=h;
%            j=t;
%        endif;
%    end;
%end;
%C=vary(1,i);
%sigma=vary(1,j)



% =========================================================================

end
